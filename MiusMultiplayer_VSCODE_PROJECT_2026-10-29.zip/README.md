# Проект Visual Studio Code для net-v21 (debug/release)

Снимок файлов из ветки arena/d145e85b-miusvitals, коммит d920841f9ad5e04618e569928b18cc68661f698a, 2026-10-29.

Что внутри:

| Файл | Что это |
|---|---|
| `.vscode/tasks.json` | 14 задач: сборка module/baseline/selftest/join/render_test/all в двух конфигурациях, прогон тестов, очистка |
| `.vscode/launch.json` | запуск: подключение к tacgame.exe / opgame.exe с символами из build\module-debug, выбор процесса, отладка тестов и mp_join |
| `.vscode/c_cpp_properties.json` | IntelliSense: MSVC Release, MSVC Debug, Portable g++ |
| `.vscode/settings.json`, `extensions.json` | ассоциации файлов и рекомендованные расширения |
| `development/net-v21/VSCODE.md` | как собирать, отлаживать и тестировать |
| `development/net-v21/build.bat` | сборка с конфигурацией: `build.bat module debug` / `release` (release по умолчанию = прежние флаги CI) |
| `development/net-v21/run_tests.bat` | прогон тех же 44 тестов, что в CI, для любой конфигурации |
| `development/net-v21/src/transform_object_check.h` | портируемая проверка объекта перед записью трансформа (13 шагов) |
| `development/net-v21/tests/transform_object_check_test.cpp` | построчный прогон этой проверки (Windows: VirtualQuery, Linux: /proc/self/maps) |
| `docs/CRASH_DUMP_2026-10-28.md` | разбор дампа падения 28.10 |
| `docs/CRASH_OUR_CODE_AUDIT_2026-10-29.md` | аудит: что в нашем коде портит память |
| `docs/REVIEW_2026-10-29.md` | полное ревью сборки 1.0.7 |

Как пользоваться: распаковать в корень репозитория (каталоги `.vscode`, `development`, `docs`
совпадают с теми, что в git), открыть папку в VS Code, `Ctrl+Shift+B`.

Содержимое по SHA-256:

6e848718d58292857a026cfd1c08aa61dde5021dfeab830a961d1a2445dbce71  .vscode/tasks.json
137f4c3e889356ac457fc0de1eae84aa4cd0454165119fb0eb89bd2f10f61dd7  .vscode/launch.json
db0db08f5d1b625959300e3f347988330f86bc5eec42ca3f1680f4fd8f5bd5b7  .vscode/c_cpp_properties.json
e991bfb27e002c2ba64355bf7267d91249cab51bf34ea66826f6253c37fedabe  .vscode/settings.json
3d82fdedb8d51009ca336240256743ae02e806556d86bbeb810f38d30323854b  .vscode/extensions.json
35939c12f2f09a12585e29e7b8d6c3360d7b4e140998cb8336f753da062544d9  development/net-v21/VSCODE.md
47745a2c1ea5acbaa956605878f78e8d9feeb1af4d18d976f4bd583909f64410  development/net-v21/build.bat
10c5ca8b602202cc2df85c62a29a598579e31eeb3326bda52ebd9960747508cf  development/net-v21/run_tests.bat
28ab17d709ed6dfd12ff52be7187f57bf15c0385ea49b84c793ee217074bc1fd  development/net-v21/src/transform_object_check.h
e63dc41d6b6527ca8e87f3a25f4d8868008c3c8752e47b548588c3e4667f0621  development/net-v21/tests/transform_object_check_test.cpp
d80a97a30c06d23031e79da808c6147404a2686c6d395cac0129e67af445f1fe  docs/CRASH_DUMP_2026-10-28.md
1bee5ace8f98a7dab8234a4f69c4d98644bb8710d67c543dbb83aa5165e97105  docs/CRASH_OUR_CODE_AUDIT_2026-10-29.md
ed2f6171eae980b17884e273406c967f78133c247d4086814ea332a45c93a399  docs/REVIEW_2026-10-29.md
